# pictures' meanings

